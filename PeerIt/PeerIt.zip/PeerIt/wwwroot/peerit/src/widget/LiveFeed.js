
import React, { Component } from 'react';
//import Webix from '../webix';

class LiveFeed extends Component {

	constructor(props) {
	      super(props);
	      this.state = {
	        data : null
	      };
  }

	render(){
		 return(<div  id="LiveFeed">
        LiveFeed
      </div>
      );
	}
}
export default LiveFeed;

